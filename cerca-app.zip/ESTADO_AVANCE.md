# Estado de avance — Cerca (MVP v1.0, fase Expo Go)

Última actualización: 30 de octubre de 2026.

## 1. Qué hay construido

**App (Expo SDK 58 + Expo Router + TypeScript strict)**

- **Acceso familiar sin contraseñas:** email + código de 6 números, alta de perfil, crear familia (14 días de prueba sin tarjeta) o unirse con el enlace de invitación. Botones de Apple y Google preparados.
- **Vinculación del mayor:** teclado numérico gigante propio (teclas de 68 dp) y lector de QR. El móvil del mayor queda unido con una sesión anónima (opción B).
- **Pantalla del mayor:** foto del día en grande con «Tu nieta Lucía · Hoy 08:45» y su texto, botón «Dar los buenos días ☀️» y confirmación fija. Si nadie subió foto hoy, muestra un «Recuerdo familiar 💛». Ver la foto también cuenta como señal. Funciona sin conexión: el saludo se encola y se envía después. Ajustes ocultos con pulsación larga de 4 s.
- **Panel de Tranquilidad (familia):** estado de hoy de cada mayor, racha de días, tarjeta prioritaria de aviso con «Llamar ahora» y «Ya hablé con…, está todo bien ✅» con nota para los hermanos.
- **Fotos:** cámara o galería, compresión real en el móvil (1280 px, WebP, ≤ 180 KB, enseña el tamaño final), pie de foto de 140 caracteres, álbum con aviso de retención (30 días en gratis, ilimitado en el Plan Familiar).
- **Mayores (hasta 4):** nombre, teléfono, Península/Canarias, 4 horas del protocolo, días activos, modo vacaciones y código de vinculación con QR.
- **Invitar por WhatsApp:** tarjetas para hermanos y para nietos con el enlace de la familia. Los admins ascienden a los hermanos en Ajustes → Familiares.
- **Suscripción:** prueba de 14 días, plan gratuito (1 mayor activo, sin avisos automáticos, fotos 30 días) y paywall ético (4,99 €/mes o 39,99 €/año) con «Restaurar compras».
- **Ajustes:** perfil, cómo te ve el mayor, emails de aviso, nombre de la familia, aviso legal (no es servicio médico ni sustituye al 112), cerrar sesión y «Eliminar mi cuenta y mis datos».
- **Modo prueba:** sin `.env`, todo funciona con datos locales de la Familia García. En desarrollo aparece la píldora «🧪 Prueba».

**Backend (`supabase/`)**

- `migrations/0001_initial_schema.sql`: 8 tablas, RLS en el 100 %, privilegios por columna, funciones RPC y bucket privado `family-moments`.
- `migrations/0002_cron_setup.sql`: pg_cron + pg_net. `evaluate-checkins` cada 5 minutos y `cleanup-expired-media` cada día a las 04:00 UTC.
- 5 Edge Functions validadas con Zod: `redeem-pairing-code`, `evaluate-checkins`, `cleanup-expired-media`, `revenuecat-webhook` y `delete-account`.
- `config.toml` listo: sesiones anónimas activadas, plantillas de email con el código y `verify_jwt` desactivado en las funciones que usan su propio secreto.

## 2. Verificaciones hechas antes de entregar

| Comprobación | Resultado |
|---|---|
| `npx tsc --noEmit` (incluidas las rutas tipadas de Expo Router) | 0 errores |
| `npm run lint` (250 líneas, sin Supabase en `.tsx`, sin `any`) | 0 errores |
| Archivos de `src/` por encima de 250 líneas | Ninguno (el mayor tiene 164) |
| `npx expo export --platform android` (bundle completo de Metro) | Compila: 3.986 módulos |
| `deno check` de las 5 Edge Functions | 0 errores |
| Edge Functions en marcha: rechazan peticiones sin permiso o mal formadas | OK |
| Migraciones aplicadas en un Postgres que imita Supabase + pruebas de seguridad | OK |

**Lo que NO se ha podido probar desde mi entorno:** la app en un móvil real, Supabase real con Docker y el envío real de push y emails. Es lo primero que haremos juntos.

## 3. Cómo meterlo en tu proyecto (Windows)

1. Cierra VS Code.
2. Descomprime `cerca-app.zip` y copia **todo su contenido** dentro de `C:\dev\cerca-app`. Cuando Windows pregunte, elige **Reemplazar los archivos en el destino**. Tu `CONTEXT.md`, tu carpeta `.git` y tus `assets` no se tocan.
3. Abre VS Code en `C:\dev\cerca-app` y, en la terminal, un comando cada vez:
   ```bash
   npm install
   ```
   ```bash
   npx expo start
   ```
4. Instala **Expo Go** en tu móvil (Play Store o App Store). Con el móvil en la misma WiFi que el PC:
   - **Android:** abre Expo Go y escanea el QR de la terminal.
   - **iPhone:** escanea el QR con la cámara normal.
   - Si no conecta: para con `Ctrl + C` y arranca con `npx expo start --tunnel`.
5. Guárdalo en una rama, como manda AGENTS.md:
   ```bash
   git checkout -b feat/mvp-base
   git add .
   git commit -m "feat: MVP base with demo mode, Supabase schema and edge functions"
   git push -u origin feat/mvp-base
   ```
   Después abre la Pull Request en GitHub para que la revise tu socio.

## 4. Cómo probar todos los flujos en el móvil (modo prueba)

| Qué probar | Cómo |
|---|---|
| Entrar como hijo | «Soy familiar» → cualquier email → cualquier código de 6 cifras |
| Entrar como nieta | Igual, con el email `lucia@ejemplo.es` |
| Cambiar de vista al instante | Píldora «🧪 Prueba» (arriba a la derecha) → hijo, abuela o nieta |
| Pantalla de la abuela | Píldora → «Vista abuela» → pulsa «Dar los buenos días ☀️» |
| Día sin foto nueva | Píldora → «Día sin foto nueva»: aparece el «Recuerdo familiar 💛» |
| Aviso de las 11:30 | Píldora → «Simular 11:30 sin respuesta»: tarjeta con «Llamar ahora» y «Ya hablé con…» |
| Vincular un móvil | Hijo → Mayores → Abuela Carmen → «Generar código» → Píldora «Cerrar sesión» → «Soy el mayor» → teclea el código |
| Subir una foto real | Hijo → «Subir foto» → cámara o galería: verás el tamaño final (≤ 180 KB) |
| Fin de la prueba gratuita | Píldora → «Simular fin de la prueba»: banners, álbum de 30 días y el segundo mayor pide el Plan Familiar |
| Pago de prueba | Paywall → «Activar el Plan Familiar» (en modo prueba se activa sin pagar) |
| Empezar de cero | Píldora → «Reiniciar datos de prueba» |

## 5. Conectar Supabase real (cuando toque)

**En local (con Docker Desktop abierto):**

1. `npx supabase start`. No hace falta `supabase init`: el `config.toml` ya va incluido. Las migraciones se aplican solas.
2. Los emails con el código se ven en **http://127.0.0.1:54324** (buzón local, no llegan a tu correo).
3. Regenera los tipos: `npm run db:types`.
4. Copia `.env.example` como `.env` y rellénalo con la **IP de tu PC en la WiFi** (por ejemplo `http://192.168.1.40:54321`, la ves con `ipconfig`) y la `anon key` que muestra `supabase start`. Desde el móvil, `127.0.0.1` no funciona.
5. Reinicia la app limpiando la caché: `npx expo start -c`. La píldora desaparece y todo va contra Supabase.
6. Edge Functions en local: copia `supabase/functions/.env.example` como `supabase/functions/.env`, rellénalo y ejecuta `npx supabase functions serve`.
7. Para que el cron local llame a las funciones, en el SQL Editor de Studio (http://127.0.0.1:54323):
   ```sql
   select vault.create_secret('http://host.docker.internal:54321', 'project_url');
   select vault.create_secret('<el mismo CRON_SECRET del .env de funciones>', 'cron_secret');
   ```

**En la nube (Frankfurt), te guiaré paso a paso cuando lleguemos:** crear el proyecto en `eu-central-1`, `npx supabase link`, `npx supabase db push`, desplegar las funciones, `npx supabase secrets set --env-file supabase/functions/.env`, activar las sesiones anónimas, poner `{{ .Token }}` en las plantillas de email y crear los dos secretos de Vault con la URL del proyecto.

## 6. Decisiones tomadas (y por qué)

- **Expo Go en esta fase** (lo pediste para probar ya): por eso AsyncStorage en vez de MMKV, y push, RevenueCat y Sentry van detrás de adaptadores. Se cambia al pasar a development build.
- **`StyleSheet` con tokens en vez de NativeWind:** cero configuración que pueda romper el arranque en Expo Go. Los tokens ya separan Modo Mayor y Modo Familia.
- **Opción B para el mayor:** sesión anónima + código. Por eso su nombre y zona horaria viven en `elder_monitors`.
- **Un enlace de invitación por familia** (como el modelo v2.0): todos entran como «familiar» y un admin asciende a los hermanos.
- **Saludo de la mañana:** el push «tu familia te ha dejado una foto» sale al empezar la ventana del mayor (07:30 por defecto). El blueprint menciona las 09:00, pero no había un campo para esa hora.
- **Ver la foto cuenta como saludo** desde el inicio de la ventana hasta el final del día, para evitar falsos avisos.
- **La familia recibe «La abuela ya os ha dado los buenos días»** desde el cron, con un retraso máximo de 5 minutos y sin duplicados (columna `family_notified_at`).

## 7. Pendiente

1. Probar en tu móvil y ajustar lo visual que haga falta.
2. Levantar Supabase local y ejecutar los flujos reales (Bloque C).
3. Development build con EAS: push reales (`expo-notifications`), RevenueCat, Apple/Google, Sentry y PostHog.
4. Tests automatizados de la lógica pura: rachas, estados del día y foto del día.
5. Regenerar `database.types.ts` con `npm run db:types` (ahora está escrito a mano con el mismo formato).
6. El límite de intentos de `redeem-pairing-code` es por instancia; para producción conviene guardarlo en la base de datos.
7. Si un familiar pertenece a varias familias, de momento se abre la primera.
