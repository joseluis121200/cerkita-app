import { z } from 'npm:zod@4';

import { adminClient, isCronRequest } from '../_shared/clients.ts';
import { errorResponse, json, readJson } from '../_shared/http.ts';
import { hasFullPlan, type FamilyPlanRow } from '../_shared/plan.ts';

// Cron diario (04:00 UTC): plan gratuito → fotos de más de 30 días fuera (CONTEXT.md 3.2.5).
// También pasa a 'free_limited' las familias cuya prueba o suscripción ya terminó.
const bodySchema = z.object({ triggered_at: z.string().optional() }).nullable();
const BUCKET = 'family-moments';
const RETENTION_DAYS = 30;

type FamilyRow = FamilyPlanRow & { id: string };

Deno.serve(async (req) => {
  const parsed = bodySchema.safeParse(await readJson(req));
  if (!parsed.success) {
    return errorResponse('Invalid payload', 400);
  }
  if (!isCronRequest(req)) {
    return errorResponse('Unauthorized', 401);
  }

  const admin = adminClient();
  const now = new Date();
  const cutoff = new Date(now.getTime() - RETENTION_DAYS * 24 * 60 * 60 * 1000).toISOString();

  const { data: families, error } = await admin.from('families').select('id, plan_status, trial_ends_at, paid_until');
  if (error !== null) {
    console.error('families query failed', error.message);
    return errorResponse('Cleanup failed', 500);
  }

  let downgraded = 0;
  let removed = 0;
  for (const family of (families ?? []) as FamilyRow[]) {
    if (hasFullPlan(family, now)) {
      continue;
    }
    if (family.plan_status !== 'free_limited') {
      const { error: updateError } = await admin.from('families').update({ plan_status: 'free_limited' }).eq('id', family.id);
      if (updateError === null) {
        downgraded += 1;
      }
    }

    const { data: old, error: oldError } = await admin
      .from('moments')
      .select('id, storage_path')
      .eq('family_id', family.id)
      .lt('created_at', cutoff)
      .limit(1000);
    if (oldError !== null || old === null || old.length === 0) {
      continue;
    }
    const rows = old as { id: string; storage_path: string }[];
    for (let i = 0; i < rows.length; i += 100) {
      const chunk = rows.slice(i, i + 100);
      const { error: removeError } = await admin.storage.from(BUCKET).remove(chunk.map((r) => r.storage_path));
      if (removeError !== null) {
        console.error('storage remove failed', family.id, removeError.message);
        continue;
      }
      await admin.from('moments').delete().in('id', chunk.map((r) => r.id));
      removed += chunk.length;
    }
  }
  return json({ downgraded, removed });
});
