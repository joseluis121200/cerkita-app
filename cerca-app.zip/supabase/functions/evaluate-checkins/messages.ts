import type { PushMessage } from '../_shared/notify.ts';

// Textos cálidos. Prohibido: "alarma", "emergencia", "vigilancia"… (AGENTS.md 1).
export const elderMorning: PushMessage = {
  title: 'Buenos días ☀️',
  body: 'Tu familia te ha dejado una foto. Toca aquí para verla y saludar.',
};

export const elderReminder1: PushMessage = {
  title: '¿Nos das los buenos días? ☀️',
  body: 'Tu familia está deseando saber de ti. Toca aquí para saludar.',
};

export const elderReminder2: PushMessage = {
  title: 'Tu familia te manda un abrazo 💛',
  body: 'Toca aquí para dar los buenos días.',
  priority: 'high',
};

export function adminAlertPush(elderName: string, elderId: string): PushMessage {
  return {
    title: `${elderName} aún no ha dado los buenos días`,
    body: 'Lo más probable es que esté bien. Llámale para quedaros tranquilos.',
    priority: 'high',
    data: { type: 'alert', elderId },
  };
}

export function adminAlertEmail(elderName: string): { subject: string; html: string } {
  return {
    subject: `${elderName} aún no ha dado los buenos días`,
    html: `<p>Hola,</p>
<p><strong>${elderName}</strong> todavía no ha dado los buenos días en Cerca y ya ha pasado su hora habitual.</p>
<p>Lo más probable es que esté bien. Una llamada rápida os dejará a todos tranquilos. Cuando habléis con él o ella,
pulsad «Ya hablé con…» en la app para avisar al resto de la familia.</p>
<p style="color:#6B5B4D;font-size:12px">Cerca es una red de comunicación familiar. No es un servicio médico ni de emergencias:
ante cualquier urgencia, llama al 112.</p>`,
  };
}

export function familyGreeting(elderName: string): PushMessage {
  return { title: `${elderName} os ha dado los buenos días ☀️`, body: '¡Sube la foto de hoy para alegrarle la mañana!' };
}

export function familyResolved(elderName: string, resolverName: string): PushMessage {
  return { title: `Todo bien con ${elderName} ✅`, body: `${resolverName} ya ha hablado con ${elderName}.` };
}
