// Mismas reglas que src/features/subscription/plan.ts, aplicadas en el servidor (quien decide).
export type FamilyPlanRow = { plan_status: string; trial_ends_at: string; paid_until: string | null };

export function hasFullPlan(family: FamilyPlanRow, now: Date): boolean {
  if (family.plan_status === 'active_paid') {
    return family.paid_until === null || new Date(family.paid_until).getTime() > now.getTime();
  }
  if (family.plan_status === 'grace_period') {
    return true;
  }
  if (family.plan_status === 'trialing') {
    return new Date(family.trial_ends_at).getTime() > now.getTime();
  }
  return false;
}
