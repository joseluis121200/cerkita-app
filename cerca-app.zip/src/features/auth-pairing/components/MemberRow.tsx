import { StyleSheet, View } from 'react-native';

import { AppText, Button, familyColors, familySpacing } from '@/shared/ui-family';

import { roleLabel, type FamilyMember } from '../schemas';

type Props = {
  member: FamilyMember;
  isMe: boolean;
  canManage: boolean;
  onToggleAdmin: (member: FamilyMember) => void;
  busy: boolean;
};

export function MemberRow({ member, isMe, canManage, onToggleAdmin, busy }: Props) {
  const showAction = canManage && !isMe && member.role !== 'elder';
  return (
    <View style={styles.row}>
      <View style={styles.info}>
        <AppText bold>{isMe ? `${member.displayName} (tú)` : member.displayName}</AppText>
        <AppText variant="muted">{member.label ?? roleLabel(member.role)}</AppText>
      </View>
      <AppText variant="tiny" style={styles.badge}>
        {roleLabel(member.role)}
      </AppText>
      {showAction && (
        <Button
          title={member.role === 'admin' ? 'Quitar admin' : 'Hacer admin'}
          variant="secondary"
          loading={busy}
          onPress={() => onToggleAdmin(member)}
          style={styles.action}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: familySpacing.sm,
    paddingVertical: familySpacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: familyColors.border,
  },
  info: { flex: 1 },
  badge: {
    backgroundColor: familyColors.surfaceWarm,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
    overflow: 'hidden',
  },
  action: { minHeight: 40, paddingHorizontal: 10 },
});
