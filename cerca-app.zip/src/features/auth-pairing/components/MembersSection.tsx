import { useState } from 'react';

import { toUserMessage } from '@/shared/api/errors';
import { AppText, Card, Notice } from '@/shared/ui-family';

import { useMembers, useSetMemberRole } from '../family-hooks';
import type { FamilyMember } from '../schemas';
import { MemberRow } from './MemberRow';

type Props = { familyId: string; myUserId: string; isAdmin: boolean };

export function MembersSection({ familyId, myUserId, isAdmin }: Props) {
  const members = useMembers(familyId);
  const setRole = useSetMemberRole(familyId);
  const [busyId, setBusyId] = useState<string | null>(null);

  function toggleAdmin(member: FamilyMember) {
    setBusyId(member.id);
    setRole.mutate(
      { memberId: member.id, role: member.role === 'admin' ? 'member' : 'admin' },
      { onSettled: () => setBusyId(null) },
    );
  }

  const family = (members.data ?? []).filter((m) => m.role !== 'elder');

  return (
    <Card>
      <AppText variant="heading">{`Familiares (${family.length}/10)`}</AppText>
      <AppText variant="muted">
        Los administradores configuran a los mayores y reciben los avisos. Haz administradores a tus hermanos.
      </AppText>
      {family.map((member) => (
        <MemberRow
          key={member.id}
          member={member}
          isMe={member.userId === myUserId}
          canManage={isAdmin}
          busy={busyId === member.id}
          onToggleAdmin={toggleAdmin}
        />
      ))}
      {setRole.isError && <Notice tone="warning" text={toUserMessage(setRole.error)} />}
    </Card>
  );
}
