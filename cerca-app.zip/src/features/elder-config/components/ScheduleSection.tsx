import { StyleSheet, View } from 'react-native';

import { AppText, familySpacing } from '@/shared/ui-family';

import type { ElderInput } from '../schemas';
import { TimeStepper } from './TimeStepper';

type Props = { values: ElderInput; onChange: (changes: Partial<ElderInput>) => void };

export function ScheduleSection({ values, onChange }: Props) {
  return (
    <View style={styles.wrapper}>
      <AppText variant="heading">Horario de tranquilidad</AppText>
      <AppText variant="muted">Si no da los buenos días, primero le recordamos con cariño y solo después os avisamos.</AppText>
      <TimeStepper
        label="Empieza la mañana"
        helper="Desde esta hora cuenta su saludo"
        value={values.windowStart}
        onChange={(time) => onChange({ windowStart: time })}
      />
      <TimeStepper
        label="Primer recordatorio suave"
        helper="Notificación amable en su móvil"
        value={values.reminder1At}
        onChange={(time) => onChange({ reminder1At: time })}
      />
      <TimeStepper
        label="Segundo recordatorio"
        helper="Otro aviso con sonido en su móvil"
        value={values.reminder2At}
        onChange={(time) => onChange({ reminder2At: time })}
      />
      <TimeStepper
        label="Aviso a la familia"
        helper="Push + email a los administradores"
        value={values.adminAlertAt}
        onChange={(time) => onChange({ adminAlertAt: time })}
      />
    </View>
  );
}

const styles = StyleSheet.create({ wrapper: { gap: familySpacing.xs } });
