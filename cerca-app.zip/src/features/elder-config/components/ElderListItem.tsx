import { ChevronRight } from 'lucide-react-native';
import { Pressable, StyleSheet, View } from 'react-native';

import { AppText, familyColors, familyRadius, familySpacing } from '@/shared/ui-family';

import { describeActiveDays, TIME_ZONE_LABELS, type Elder } from '../schemas';

type Props = { elder: Elder; onPress: () => void; inactiveByPlan: boolean };

export function ElderListItem({ elder, onPress, inactiveByPlan }: Props) {
  const status = !elder.isPaired
    ? 'Móvil sin vincular'
    : inactiveByPlan
      ? 'Sin avisos en el plan gratuito'
      : `Aviso a la familia a las ${elder.adminAlertAt}`;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Configurar a ${elder.displayName}`}
      onPress={onPress}
      style={({ pressed }) => [styles.row, pressed && styles.pressed]}
    >
      <View style={styles.avatar}>
        <AppText variant="heading">{elder.displayName.slice(0, 1).toUpperCase()}</AppText>
      </View>
      <View style={styles.info}>
        <AppText bold>{elder.displayName}</AppText>
        <AppText variant="muted">{status}</AppText>
        <AppText variant="tiny">{`${TIME_ZONE_LABELS[elder.timezone]} · ${describeActiveDays(elder.activeDaysMask)}`}</AppText>
      </View>
      <ChevronRight size={22} color={familyColors.textMuted} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: familySpacing.md,
    padding: familySpacing.md,
    borderRadius: familyRadius.lg,
    borderWidth: 1,
    borderColor: familyColors.border,
    backgroundColor: familyColors.surface,
  },
  pressed: { backgroundColor: familyColors.surfaceWarm },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: familyColors.warningSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  info: { flex: 1, gap: 2 },
});
