import { StyleSheet, View } from 'react-native';

import { ElderText, elderColors, elderSizes } from '@/shared/ui-elder';

type Props = { at: string | null; timeZone: string };

function formatTime(iso: string, timeZone: string): string {
  return new Intl.DateTimeFormat('es-ES', { hour: '2-digit', minute: '2-digit', timeZone }).format(new Date(iso));
}

// Mensaje fijo (no desaparece solo) que confirma al mayor que su familia ya recibió su saludo.
export function GreetingConfirmation({ at, timeZone }: Props) {
  return (
    <View style={styles.box} accessibilityLiveRegion="polite" accessible>
      <ElderText variant="title" color={elderColors.calm} center>
        ¡Ya has dado los buenos días a tu familia! ☀️
      </ElderText>
      {at !== null && (
        <ElderText color={elderColors.calm} center>
          {`Saludo enviado a las ${formatTime(at, timeZone)}`}
        </ElderText>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    backgroundColor: elderColors.calmSoft,
    borderRadius: elderSizes.radius,
    padding: 24,
    gap: 8,
    borderWidth: 2,
    borderColor: '#86EFAC',
  },
});
