import { Flame, Phone } from 'lucide-react-native';
import { Linking, StyleSheet, View } from 'react-native';

import type { FamilyMember } from '@/features/auth-pairing';
import { AppText, Button, Card, familyColors, familySpacing } from '@/shared/ui-family';
import { initialOf, telUrl } from '@/shared/utils/format';
import { logError } from '@/shared/utils/logger';

import { describeDayState } from '../describe';
import type { ElderOverview } from '../hooks';

type Props = { overview: ElderOverview; members: FamilyMember[] };

const toneToCard = { calm: 'calm', warm: 'warm', alert: 'alert', muted: 'default' } as const;

export function callPhone(phone: string): void {
  Linking.openURL(telUrl(phone)).catch((error: unknown) => logError('call-phone', error));
}

export function ElderStatusCard({ overview, members }: Props) {
  const { elder, state, streak, alertsPausedByPlan } = overview;
  const text = describeDayState(state, elder.timezone, members);

  return (
    <Card tone={toneToCard[text.tone]}>
      <View style={styles.header}>
        <View style={styles.avatar}>
          <AppText variant="heading">{initialOf(elder.displayName)}</AppText>
        </View>
        <View style={styles.flex}>
          <AppText variant="heading">{elder.displayName}</AppText>
          <AppText bold color={text.tone === 'calm' ? familyColors.calmText : familyColors.text}>
            {text.title}
          </AppText>
          {text.detail !== null && <AppText variant="muted">{text.detail}</AppText>}
        </View>
      </View>
      <View style={styles.footer}>
        <View style={styles.streak}>
          <Flame size={18} color={familyColors.terracotta} />
          <AppText variant="small">{streak === 1 ? '1 día conectados' : `${streak} días seguidos conectados`}</AppText>
        </View>
        {elder.phoneForCall !== null && (
          <Button
            title="Llamar"
            variant="secondary"
            icon={<Phone size={16} color={familyColors.text} />}
            onPress={() => callPhone(elder.phoneForCall ?? '')}
            accessibilityLabel={`Llamar a ${elder.displayName}`}
            style={styles.call}
          />
        )}
      </View>
      {alertsPausedByPlan && (
        <AppText variant="tiny">Plan gratuito: sin avisos automáticos para este mayor.</AppText>
      )}
    </Card>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', gap: familySpacing.md, alignItems: 'flex-start' },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: familyColors.white,
    borderWidth: 1,
    borderColor: familyColors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  flex: { flex: 1, gap: 2 },
  footer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: familySpacing.sm },
  streak: { flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 },
  call: { minHeight: 40 },
});
