import { ElderButton } from '@/shared/ui-elder';

type Props = { onPress: () => void; loading: boolean };

export function GoodMorningButton({ onPress, loading }: Props) {
  return (
    <ElderButton
      title="Dar los buenos días ☀️"
      onPress={onPress}
      loading={loading}
      accessibilityLabel="Dar los buenos días a la familia"
      accessibilityHint="Tu familia recibirá tu saludo al momento"
    />
  );
}
