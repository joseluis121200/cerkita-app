import type { FamilyMember } from '@/features/auth-pairing';
import { formatClock } from '@/shared/utils/format';

import type { ElderDayState } from './schemas';
import { shortDate } from './status';

export type DayStateText = { title: string; detail: string | null; tone: 'calm' | 'warm' | 'alert' | 'muted' };

// Textos del panel de tranquilidad. En la interfaz familiar decimos "aviso", nunca "alarma".
export function describeDayState(state: ElderDayState, timeZone: string, members: FamilyMember[]): DayStateText {
  switch (state.kind) {
    case 'ok': {
      const at = state.at === null ? '' : ` a las ${formatClock(state.at, timeZone)}`;
      const verb = state.source === 'photo_opened' ? 'Vio la foto del día' : 'Dio los buenos días';
      return { title: `${verb}${at} ☀️`, detail: null, tone: 'calm' };
    }
    case 'resolved': {
      const who = members.find((m) => m.userId === state.byUserId)?.displayName;
      return {
        title: 'Todo bien ✅',
        detail: `${who !== undefined ? `Confirmado por ${who}` : 'Confirmado por la familia'}${state.note !== null ? ` · «${state.note}»` : ''}`,
        tone: 'calm',
      };
    }
    case 'alerted':
      return { title: 'Aún no ha dado señales hoy', detail: 'Llámale para quedaros tranquilos.', tone: 'alert' };
    case 'reminded':
      return {
        title: 'Pendiente de saludar',
        detail: state.level === 1 ? 'Le hemos enviado un recordatorio suave.' : 'Le hemos enviado un segundo recordatorio.',
        tone: 'warm',
      };
    case 'pending':
      return { title: 'Pendiente de saludar', detail: null, tone: 'warm' };
    case 'paused':
      return { title: `Modo vacaciones hasta el ${shortDate(state.until)}`, detail: 'Sin recordatorios ni avisos.', tone: 'muted' };
    case 'rest_day':
      return { title: 'Hoy no hay avisos', detail: 'Día sin aviso según su configuración.', tone: 'muted' };
    case 'disabled':
      return { title: 'Avisos desactivados', detail: 'Actívalos en «Mayores».', tone: 'muted' };
    case 'not_paired':
      return { title: 'Falta vincular su móvil', detail: 'Genera su código en «Mayores».', tone: 'muted' };
  }
}
