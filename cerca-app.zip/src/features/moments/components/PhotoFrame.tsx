import { Image } from 'expo-image';
import { StyleSheet, View } from 'react-native';

import { ElderText, elderColors, elderSizes } from '@/shared/ui-elder';
import { formatClock } from '@/shared/utils/format';
import { relativeDayLabel } from '@/shared/utils/dates';

import { authorForElder, type PhotoOfTheDay } from '../schemas';

type Props = { photo: PhotoOfTheDay; timeZone: string };

// Marco grande de la foto del día para el mayor. Si no hay foto nueva, muestra un recuerdo.
export function PhotoFrame({ photo, timeZone }: Props) {
  const { moment, isMemory } = photo;
  const when = `${relativeDayLabel(moment.createdAt, timeZone)} · ${formatClock(moment.createdAt, timeZone)}`;

  return (
    <View style={styles.frame}>
      {isMemory && (
        <View style={styles.memoryBadge}>
          <ElderText variant="large" color={elderColors.memory}>
            Recuerdo familiar 💛
          </ElderText>
        </View>
      )}
      <Image
        source={{ uri: moment.imageUrl }}
        style={styles.image}
        contentFit="cover"
        transition={300}
        accessibilityLabel={moment.caption ?? 'Foto de tu familia'}
      />
      <View style={styles.texts}>
        <ElderText variant="large">{`${authorForElder(moment)} · ${when}`}</ElderText>
        {moment.caption !== null && moment.caption.length > 0 && <ElderText variant="title">{moment.caption}</ElderText>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  frame: {
    backgroundColor: elderColors.frame,
    borderRadius: elderSizes.radius,
    borderWidth: 2,
    borderColor: elderColors.border,
    overflow: 'hidden',
  },
  memoryBadge: { backgroundColor: elderColors.memorySoft, paddingVertical: 10, paddingHorizontal: 18 },
  image: { width: '100%', aspectRatio: 3 / 4, backgroundColor: elderColors.memorySoft },
  texts: { padding: 18, gap: 8 },
});
