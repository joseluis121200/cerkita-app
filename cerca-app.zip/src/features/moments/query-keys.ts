export const momentKeys = {
  list: (familyId: string) => ['moments', familyId] as const,
  simulation: ['moments-simulation'] as const,
};
