import { demoLatency, readDemo, updateDemo } from '@/shared/demo';
import { createId } from '@/shared/utils/ids';

import type { Moment } from './schemas';

export async function demoFetchMoments(): Promise<Moment[]> {
  const state = await readDemo();
  const sorted = [...state.moments].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return sorted.map((m) => ({
    id: m.id,
    familyId: state.family.id,
    authorId: m.authorId,
    imageUrl: m.imageUrl,
    storagePath: null,
    caption: m.caption,
    createdAt: m.createdAt,
  }));
}

export async function demoUploadMoment(localUri: string, caption: string | null): Promise<void> {
  await demoLatency(700);
  await updateDemo((state) => {
    const authorId = state.persona.kind === 'family' ? state.persona.userId : 'desconocido';
    // En modo prueba la foto se queda en el móvil (la URI ya comprimida).
    state.moments.push({ id: createId(), authorId, imageUrl: localUri, caption, createdAt: new Date().toISOString() });
    state.hideTodayPhotos = false;
  });
}

export async function demoDeleteMoment(momentId: string): Promise<void> {
  await demoLatency();
  await updateDemo((state) => {
    state.moments = state.moments.filter((m) => m.id !== momentId);
  });
}

export async function demoHideTodayFlag(): Promise<boolean> {
  const state = await readDemo();
  return state.hideTodayPhotos;
}
