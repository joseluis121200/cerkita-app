import type { Family } from '@/features/auth-pairing';
import { daysUntil } from '@/shared/utils/dates';

// Reglas del plan (CONTEXT.md 3.2 punto 5). El servidor es quien aplica las restricciones;
// aquí solo calculamos qué mostrar.
export type EffectivePlan = {
  kind: 'trial' | 'paid' | 'grace' | 'free';
  daysLeft: number | null;
  alertsEnabled: boolean;
  maxActiveElders: number;
  photoRetentionDays: number | null;
};

export function effectivePlan(family: Pick<Family, 'planStatus' | 'trialEndsAt' | 'paidUntil'>, now: Date = new Date()): EffectivePlan {
  const paid: EffectivePlan = { kind: 'paid', daysLeft: null, alertsEnabled: true, maxActiveElders: 4, photoRetentionDays: null };
  const free: EffectivePlan = { kind: 'free', daysLeft: null, alertsEnabled: false, maxActiveElders: 1, photoRetentionDays: 30 };

  if (family.planStatus === 'active_paid') {
    if (family.paidUntil === null || new Date(family.paidUntil).getTime() > now.getTime()) {
      return paid;
    }
    return free;
  }
  if (family.planStatus === 'grace_period') {
    return { ...paid, kind: 'grace' };
  }
  if (family.planStatus === 'trialing') {
    const daysLeft = daysUntil(family.trialEndsAt, now);
    if (daysLeft > 0) {
      return { ...paid, kind: 'trial', daysLeft };
    }
  }
  return free;
}

export const PLAN_FEATURES = [
  'Avisos automáticos de tranquilidad (push + email) si un día no saluda',
  'Hasta 4 mayores y 10 familiares con un solo pago',
  'Álbum familiar ilimitado: las fotos no caducan',
  'Recordatorios suaves para el mayor antes de avisaros',
] as const;

export type PlanOption = 'monthly' | 'yearly';

export const PLAN_OPTIONS: Record<PlanOption, { title: string; price: string; detail: string; badge: string | null }> = {
  yearly: { title: 'Anual', price: '39,99 €/año', detail: 'Sale a 3,33 € al mes por toda la familia', badge: 'Ahorra un 33 %' },
  monthly: { title: 'Mensual', price: '4,99 €/mes', detail: 'Cancela cuando quieras', badge: null },
};
