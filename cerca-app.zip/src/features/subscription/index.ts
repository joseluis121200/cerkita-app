// API pública de la feature subscription.
export { PlanBanner } from './components/PlanBanner';
export { PlanOptionCard } from './components/PlanOptionCard';
export { usePlan, usePurchasePlan, useRestorePurchases } from './hooks';
export { effectivePlan, PLAN_FEATURES, PLAN_OPTIONS } from './plan';
export type { EffectivePlan, PlanOption } from './plan';
export type { PurchaseResult } from './purchases';
