import { Crown } from 'lucide-react-native';
import { Pressable, StyleSheet, View } from 'react-native';

import { AppText, familyColors, familyRadius, familySpacing } from '@/shared/ui-family';

import type { EffectivePlan } from '../plan';

type Props = { plan: EffectivePlan; onPress: () => void };

function describe(plan: EffectivePlan): { title: string; detail: string; tone: 'warm' | 'calm' | 'warning' } {
  if (plan.kind === 'trial') {
    const days = plan.daysLeft ?? 0;
    return {
      title: `Prueba gratuita: ${days} ${days === 1 ? 'día' : 'días'}`,
      detail: 'Todo desbloqueado, sin tarjeta.',
      tone: 'warm',
    };
  }
  if (plan.kind === 'paid') {
    return { title: 'Plan Familiar activo', detail: 'Avisos automáticos y álbum ilimitado.', tone: 'calm' };
  }
  if (plan.kind === 'grace') {
    return { title: 'Hay un problema con el pago', detail: 'Revisa tu método de pago en la tienda.', tone: 'warning' };
  }
  return {
    title: 'Plan gratuito',
    detail: 'Los avisos automáticos están en pausa. Toca para ver el Plan Familiar.',
    tone: 'warning',
  };
}

const backgrounds = { warm: familyColors.surfaceWarm, calm: familyColors.calmSoft, warning: familyColors.warningSoft };

export function PlanBanner({ plan, onPress }: Props) {
  const info = describe(plan);
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${info.title}. ${info.detail}`}
      onPress={onPress}
      style={[styles.banner, { backgroundColor: backgrounds[info.tone] }]}
    >
      <Crown size={22} color={familyColors.terracotta} />
      <View style={styles.texts}>
        <AppText bold>{info.title}</AppText>
        <AppText variant="tiny">{info.detail}</AppText>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: familySpacing.md,
    padding: familySpacing.md,
    borderRadius: familyRadius.md,
  },
  texts: { flex: 1 },
});
