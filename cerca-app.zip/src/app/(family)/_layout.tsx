import { Redirect, Tabs } from 'expo-router';
import { Camera, House, Images, Settings, Users } from 'lucide-react-native';
import { useEffect } from 'react';

import { useFamilyContext, useRegisterPushToken, useSession } from '@/features/auth-pairing';
import { familyColors, LoadingState } from '@/shared/ui-family';

// Shell de hijos y nietos: 5 pestañas. Invitar, Paywall y la ficha de cada mayor van ocultas.
export default function FamilyLayout() {
  const { isLoading } = useSession();
  const family = useFamilyContext();
  const registerPush = useRegisterPushToken();
  const familyId = family?.familyId;

  useEffect(() => {
    if (familyId !== undefined) {
      registerPush.mutate();
    }
    // Solo una vez por familia: registerPush es estable para TanStack Query.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [familyId]);

  if (isLoading) {
    return <LoadingState />;
  }
  if (family === null) {
    return <Redirect href="/" />;
  }

  return (
    <Tabs
      backBehavior="history"
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: familyColors.terracotta,
        tabBarInactiveTintColor: familyColors.textMuted,
        tabBarStyle: { backgroundColor: familyColors.surface, borderTopColor: familyColors.border },
        tabBarLabelStyle: { fontSize: 12, fontWeight: '600' },
      }}
    >
      <Tabs.Screen name="home" options={{ title: 'Tranquilidad', tabBarIcon: ({ color, size }) => <House color={color} size={size} /> }} />
      <Tabs.Screen name="upload" options={{ title: 'Subir foto', tabBarIcon: ({ color, size }) => <Camera color={color} size={size} /> }} />
      <Tabs.Screen name="album" options={{ title: 'Álbum', tabBarIcon: ({ color, size }) => <Images color={color} size={size} /> }} />
      <Tabs.Screen name="elders" options={{ title: 'Mayores', tabBarIcon: ({ color, size }) => <Users color={color} size={size} /> }} />
      <Tabs.Screen name="settings" options={{ title: 'Ajustes', tabBarIcon: ({ color, size }) => <Settings color={color} size={size} /> }} />
      <Tabs.Screen name="elder/[id]" options={{ href: null }} />
      <Tabs.Screen name="invite" options={{ href: null }} />
      <Tabs.Screen name="paywall" options={{ href: null }} />
    </Tabs>
  );
}
