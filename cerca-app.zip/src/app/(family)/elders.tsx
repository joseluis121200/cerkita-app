import { router } from 'expo-router';
import { Plus } from 'lucide-react-native';

import { useFamilyContext } from '@/features/auth-pairing';
import { ElderListItem, useElders } from '@/features/elder-config';
import { usePlan } from '@/features/subscription';
import { AppText, Button, familyColors, LoadingState, Notice, Screen } from '@/shared/ui-family';

const MAX_ELDERS = 4;

export default function Elders() {
  const session = useFamilyContext();
  const elders = useElders(session?.familyId);
  const plan = usePlan(session?.familyId);

  if (session === null) {
    return null;
  }
  const list = elders.data ?? [];
  const isAdmin = session.role === 'admin';
  const reachedPlanLimit = plan !== null && list.length >= plan.maxActiveElders;

  function addElder() {
    // En el plan gratuito solo hay 1 mayor activo: el segundo lleva al Plan Familiar.
    if (reachedPlanLimit) {
      router.push('/paywall');
      return;
    }
    router.push('/elder/new');
  }

  return (
    <Screen>
      <AppText variant="title">Mayores</AppText>
      <AppText variant="muted">Configura sus horarios desde aquí: su móvil se actualiza solo, sin que tenga que tocar nada.</AppText>
      {elders.isLoading && <LoadingState />}
      {elders.isError && <LoadingState error="No hemos podido cargar a los mayores." onRetry={() => void elders.refetch()} />}
      {list.map((elder, index) => (
        <ElderListItem
          key={elder.id}
          elder={elder}
          inactiveByPlan={plan !== null && (!plan.alertsEnabled || index >= plan.maxActiveElders)}
          onPress={() => router.push(`/elder/${elder.id}`)}
        />
      ))}
      {!isAdmin && <Notice text="Solo los administradores pueden añadir o configurar mayores." />}
      {isAdmin && list.length < MAX_ELDERS && (
        <Button
          title={reachedPlanLimit ? 'Añadir otro mayor (Plan Familiar)' : 'Añadir mayor'}
          icon={<Plus size={20} color={familyColors.onPrimary} />}
          onPress={addElder}
        />
      )}
      {list.length >= MAX_ELDERS && <Notice text="Has llegado al máximo de 4 mayores por familia." />}
    </Screen>
  );
}
