import { router } from 'expo-router';

import { buildInviteLink, InviteShareCard, useFamily, useFamilyContext } from '@/features/auth-pairing';
import { AppText, Button, LoadingState, Notice, Screen } from '@/shared/ui-family';

// Multiplicador de WhatsApp: un solo enlace por familia (CONTEXT.md, families.invite_token).
export default function Invite() {
  const session = useFamilyContext();
  const family = useFamily(session?.familyId);

  if (session === null) {
    return null;
  }
  if (family.data === undefined) {
    return <LoadingState />;
  }
  const link = buildInviteLink(family.data.inviteToken);
  const elderNames = family.data.name;

  return (
    <Screen>
      <AppText variant="title">Invitar a la familia</AppText>
      <AppText variant="muted">Cuantos más seáis, más fotos verá cada mañana. Toda la familia entra gratis con un solo pago.</AppText>
      <InviteShareCard
        title="A tus hermanos"
        description="Podrán configurar los horarios y recibirán los avisos. Cuando entren, hazlos administradores en Ajustes → Familiares."
        message={`Te invito a ${elderNames} en Cerca ☀️ Así vemos cada mañana que los abuelos están bien y les mandamos fotos. Entra aquí: ${link}`}
      />
      <InviteShareCard
        title="A nietos, sobrinos y demás familia"
        description="Podrán subir fotos del día y ver el saludo de los abuelos."
        message={`¡Únete a ${elderNames} en Cerca! 📸 Cada mañana los abuelos ven una foto nuestra y nos dan los buenos días con un toque. Entra aquí: ${link}`}
      />
      <Notice text={`Si el enlace no abre la app, quien entre puede pegar este código al registrarse: ${family.data.inviteToken}`} />
      <Button title="Volver" variant="ghost" onPress={() => router.back()} />
    </Screen>
  );
}
