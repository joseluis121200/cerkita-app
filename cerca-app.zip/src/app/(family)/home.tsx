import { router } from 'expo-router';
import { Camera, UserPlus } from 'lucide-react-native';
import { RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useFamily, useFamilyContext, useMembers } from '@/features/auth-pairing';
import { AlertCard, ElderStatusCard, useElderOverviews } from '@/features/checkin-engine';
import { PlanBanner, usePlan } from '@/features/subscription';
import { AppText, Button, Card, familyColors, familySpacing, LoadingState } from '@/shared/ui-family';

// Panel de Tranquilidad: el estado de hoy de cada mayor, de un vistazo.
export default function Home() {
  const session = useFamilyContext();
  const familyId = session?.familyId;
  const family = useFamily(familyId);
  const members = useMembers(familyId);
  const plan = usePlan(familyId);
  const { overviews, isLoading, isError, refetch } = useElderOverviews(familyId);

  if (session === null) {
    return null;
  }
  const isAdmin = session.role === 'admin';
  const alerted = overviews.filter((o) => o.state.kind === 'alerted');
  const others = overviews.filter((o) => o.state.kind !== 'alerted');

  return (
    <SafeAreaView edges={['top']} style={styles.safe}>
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={false} onRefresh={() => void refetch()} />}
      >
        <View>
          <AppText variant="title">{`Hola, ${session.displayName} 👋`}</AppText>
          <AppText variant="muted">{family.data?.name ?? ''}</AppText>
        </View>

        {plan !== null && <PlanBanner plan={plan} onPress={() => router.push('/paywall')} />}

        {alerted.map((overview) => (
          <AlertCard key={overview.elder.id} overview={overview} familyId={session.familyId} canResolve={isAdmin} />
        ))}

        <AppText variant="heading">Hoy</AppText>
        {isLoading && <LoadingState label="Mirando cómo están…" />}
        {isError && <LoadingState error="No hemos podido cargar el estado de hoy." onRetry={() => void refetch()} />}
        {!isLoading && overviews.length === 0 && (
          <Card tone="warm">
            <AppText variant="heading">Añade a tu primer mayor</AppText>
            <AppText variant="muted">Configura sus horarios y vincula su móvil con un código de 6 números.</AppText>
            {isAdmin && <Button title="Añadir mayor" onPress={() => router.push('/elder/new')} />}
          </Card>
        )}
        {others.map((overview) => (
          <ElderStatusCard key={overview.elder.id} overview={overview} members={members.data ?? []} />
        ))}

        <Button
          title="Subir la foto de hoy"
          icon={<Camera size={20} color={familyColors.onPrimary} />}
          onPress={() => router.push('/upload')}
        />
        <Button
          title="Invitar a la familia"
          variant="secondary"
          icon={<UserPlus size={20} color={familyColors.text} />}
          onPress={() => router.push('/invite')}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: familyColors.background },
  content: { padding: familySpacing.lg, gap: familySpacing.lg, paddingBottom: familySpacing.xxl },
});
