import { useState } from 'react';

import { useFamilyContext } from '@/features/auth-pairing';
import { MomentGrid, MomentViewer, useDeleteMoment, useMoments, type MomentWithAuthor } from '@/features/moments';
import { usePlan } from '@/features/subscription';
import { AppText, LoadingState, Notice, Screen } from '@/shared/ui-family';

export default function Album() {
  const session = useFamilyContext();
  const familyId = session?.familyId;
  const { moments, isLoading, isError, refetch } = useMoments(familyId);
  const plan = usePlan(familyId);
  const remove = useDeleteMoment(familyId ?? '');
  const [selected, setSelected] = useState<MomentWithAuthor | null>(null);

  if (session === null) {
    return null;
  }
  const retention =
    plan?.photoRetentionDays !== null && plan?.photoRetentionDays !== undefined
      ? `Plan gratuito: las fotos se guardan ${plan.photoRetentionDays} días. Con el Plan Familiar, para siempre.`
      : 'Plan Familiar: tu álbum se guarda sin límite de tiempo.';

  return (
    <Screen>
      <AppText variant="title">Álbum familiar</AppText>
      <Notice tone={plan?.kind === 'free' ? 'warning' : 'calm'} text={retention} />
      {isLoading && <LoadingState label="Cargando fotos…" />}
      {isError && <LoadingState error="No hemos podido cargar el álbum." onRetry={() => void refetch()} />}
      {!isLoading && moments.length === 0 && <AppText variant="muted">Todavía no hay fotos. ¡Sube la primera! ☀️</AppText>}
      <MomentGrid moments={moments} onOpen={setSelected} />
      <MomentViewer
        moment={selected}
        canDelete={selected !== null && (selected.authorId === session.userId || session.role === 'admin')}
        deleting={remove.isPending}
        onDelete={(moment) => remove.mutate(moment, { onSuccess: () => setSelected(null) })}
        onClose={() => setSelected(null)}
      />
    </Screen>
  );
}
