import { Image } from 'expo-image';
import { router } from 'expo-router';
import { useState } from 'react';
import { StyleSheet } from 'react-native';

import { useFamilyContext } from '@/features/auth-pairing';
import { captionSchema, pickPhoto, PhotoSourceButtons, useCompressPhoto, useUploadMoment, type PickSource } from '@/features/moments';
import { toUserMessage } from '@/shared/api/errors';
import { AppText, Button, Card, familyRadius, Notice, Screen, TextField } from '@/shared/ui-family';
import type { CompressedPhoto } from '@/shared/utils/image';
import { formatKilobytes } from '@/shared/utils/image';

export default function Upload() {
  const session = useFamilyContext();
  const compress = useCompressPhoto();
  const upload = useUploadMoment(session?.familyId ?? '');
  const [photo, setPhoto] = useState<CompressedPhoto | null>(null);
  const [caption, setCaption] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  async function choose(source: PickSource) {
    setError(null);
    setSent(false);
    const result = await pickPhoto(source);
    if (result.status === 'denied') {
      setError('Necesitamos permiso para la cámara o las fotos. Puedes darlo en los ajustes del móvil.');
      return;
    }
    if (result.status === 'cancelled') {
      return;
    }
    compress.mutate(result.photo.uri, {
      onSuccess: setPhoto,
      onError: (compressError) => setError(toUserMessage(compressError)),
    });
  }

  function send() {
    if (photo === null) {
      return;
    }
    const parsed = captionSchema.safeParse(caption);
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? 'Revisa el texto');
      return;
    }
    upload.mutate(
      { photo, caption: parsed.data.length > 0 ? parsed.data : null },
      {
        onSuccess: () => {
          setPhoto(null);
          setCaption('');
          setSent(true);
        },
        onError: (uploadError) => setError(toUserMessage(uploadError)),
      },
    );
  }

  return (
    <Screen>
      <AppText variant="title">La foto de hoy</AppText>
      <AppText variant="muted">Algo sencillo de tu día: un café, el perro, el camino al trabajo. Es lo que más ilusión les hace.</AppText>
      <PhotoSourceButtons onPick={(source) => void choose(source)} disabled={compress.isPending || upload.isPending} />
      {compress.isPending && <Notice text="Preparando la foto…" />}
      {photo !== null && (
        <Card>
          <Image source={{ uri: photo.uri }} style={styles.preview} contentFit="cover" />
          <AppText variant="tiny">{`Foto optimizada: ${formatKilobytes(photo.bytes)} · ${photo.width}×${photo.height}`}</AppText>
          <TextField
            label="Un mensaje (opcional)"
            value={caption}
            onChangeText={setCaption}
            placeholder="¡Buenos días, abuela! ☀️"
            maxLength={140}
            multiline
          />
          <Button title="Compartir con la familia" loading={upload.isPending} onPress={send} />
          <Button title="Elegir otra" variant="ghost" onPress={() => setPhoto(null)} />
        </Card>
      )}
      {sent && (
        <Card tone="calm">
          <AppText variant="heading">¡Foto enviada! ☀️</AppText>
          <AppText>La verán en grande en su pantalla de la mañana.</AppText>
          <Button title="Ver el álbum" variant="secondary" onPress={() => router.push('/album')} />
        </Card>
      )}
      {error !== null && <Notice tone="warning" text={error} />}
    </Screen>
  );
}

const styles = StyleSheet.create({
  preview: { width: '100%', aspectRatio: 3 / 4, borderRadius: familyRadius.md },
});
