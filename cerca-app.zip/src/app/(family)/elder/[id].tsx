import { router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';

import { useFamilyContext } from '@/features/auth-pairing';
import {
  DEFAULT_ELDER_INPUT,
  ElderForm,
  PairingCodeCard,
  useCreateElder,
  useCreatePairingCode,
  useDeleteElder,
  useElders,
  useUpdateElder,
  type ElderInput,
  type PairingCode,
} from '@/features/elder-config';
import { toUserMessage } from '@/shared/api/errors';
import { AppText, Button, LoadingState, Notice, Screen } from '@/shared/ui-family';

// Ficha de un mayor: alta ("new") o edición + código de vinculación de su móvil.
export default function ElderDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const session = useFamilyContext();
  const familyId = session?.familyId ?? '';
  const elders = useElders(session?.familyId);
  const create = useCreateElder(familyId);
  const update = useUpdateElder(familyId);
  const remove = useDeleteElder(familyId);
  const pairingCode = useCreatePairingCode();
  const [pairing, setPairing] = useState<PairingCode | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [saved, setSaved] = useState(false);

  if (session === null) {
    return null;
  }
  if (session.role !== 'admin') {
    return (
      <Screen>
        <Notice text="Solo los administradores pueden configurar a los mayores." />
        <Button title="Volver" variant="secondary" onPress={() => router.back()} />
      </Screen>
    );
  }

  const isNew = id === 'new';
  const elder = elders.data?.find((e) => e.id === id);
  if (!isNew && elder === undefined) {
    return elders.isLoading ? <LoadingState /> : <LoadingState error="No encontramos a este mayor." onRetry={() => router.back()} />;
  }

  const initial: ElderInput = elder === undefined ? DEFAULT_ELDER_INPUT : { ...elder };
  const mutationError = create.error ?? update.error;

  function submit(values: ElderInput) {
    setSaved(false);
    if (isNew) {
      create.mutate(values, { onSuccess: (created) => router.replace(`/elder/${created.id}`) });
      return;
    }
    update.mutate({ elderId: id, values }, { onSuccess: () => setSaved(true) });
  }

  return (
    <Screen>
      <AppText variant="title">{isNew ? 'Nuevo mayor' : (elder?.displayName ?? '')}</AppText>
      {!isNew && elder !== undefined && (
        <PairingCodeCard
          elderName={elder.displayName}
          isPaired={elder.isPaired}
          pairing={pairing}
          loading={pairingCode.isPending}
          onGenerate={() => pairingCode.mutate(elder.id, { onSuccess: setPairing })}
        />
      )}
      {pairingCode.isError && <Notice tone="warning" text={toUserMessage(pairingCode.error)} />}
      <ElderForm
        key={elder?.id ?? 'new'}
        initial={initial}
        submitLabel={isNew ? 'Crear y continuar' : 'Guardar cambios'}
        saving={create.isPending || update.isPending}
        serverError={mutationError !== null ? toUserMessage(mutationError) : null}
        onSubmit={submit}
      />
      {saved && <Notice tone="calm" text="Guardado. Su móvil ya tiene los horarios nuevos ✅" />}
      {!isNew && elder !== undefined && (
        confirmDelete ? (
          <>
            <Notice tone="warning" text={`Se borrará a ${elder.displayName} y su historial. Su móvil quedará desvinculado.`} />
            <Button
              title="Sí, borrar"
              variant="danger"
              loading={remove.isPending}
              onPress={() => remove.mutate(elder.id, { onSuccess: () => router.replace('/elders') })}
            />
            <Button title="Cancelar" variant="ghost" onPress={() => setConfirmDelete(false)} />
          </>
        ) : (
          <Button title={`Quitar a ${elder.displayName} de la familia`} variant="danger" onPress={() => setConfirmDelete(true)} />
        )
      )}
    </Screen>
  );
}
