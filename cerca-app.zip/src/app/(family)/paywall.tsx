import { router } from 'expo-router';
import { Check } from 'lucide-react-native';
import { useState } from 'react';
import { StyleSheet, View } from 'react-native';

import { useFamilyContext } from '@/features/auth-pairing';
import { PLAN_FEATURES, PlanOptionCard, usePlan, usePurchasePlan, useRestorePurchases, type PlanOption } from '@/features/subscription';
import { toUserMessage } from '@/shared/api/errors';
import { AppText, Button, Card, familyColors, familySpacing, Notice, Screen } from '@/shared/ui-family';

// Paywall ético: precios claros, sin trucos, y el mayor nunca queda bloqueado.
export default function Paywall() {
  const session = useFamilyContext();
  const plan = usePlan(session?.familyId);
  const purchase = usePurchasePlan();
  const restore = useRestorePurchases();
  const [option, setOption] = useState<PlanOption>('yearly');
  const [message, setMessage] = useState<string | null>(null);

  function buy() {
    setMessage(null);
    purchase.mutate(option, {
      onSuccess: (result) => {
        if (result.status === 'purchased') {
          setMessage('¡Gracias! El Plan Familiar ya está activo para toda la familia ☀️');
        } else if (result.status === 'unavailable') {
          setMessage(result.reason);
        }
      },
      onError: (error) => setMessage(toUserMessage(error)),
    });
  }

  function restoreAll() {
    restore.mutate(undefined, {
      onSuccess: (result) => {
        if (result.status === 'unavailable') setMessage(result.reason);
        if (result.status === 'restored') setMessage(result.found ? 'Compras restauradas ✅' : 'No hemos encontrado compras anteriores.');
      },
    });
  }

  return (
    <Screen>
      <AppText variant="title">Plan Familiar Completo</AppText>
      <AppText variant="muted">Un solo pago para toda la familia. Los mayores siempre pueden ver las fotos y saludar, también sin pagar.</AppText>
      {plan?.kind === 'paid' && <Notice tone="calm" text="Tu familia ya tiene el Plan Familiar activo ✅" />}
      <Card tone="warm">
        {PLAN_FEATURES.map((feature) => (
          <View key={feature} style={styles.feature}>
            <Check size={18} color={familyColors.calmText} />
            <AppText style={styles.flex}>{feature}</AppText>
          </View>
        ))}
      </Card>
      <PlanOptionCard option="yearly" selected={option === 'yearly'} onSelect={() => setOption('yearly')} />
      <PlanOptionCard option="monthly" selected={option === 'monthly'} onSelect={() => setOption('monthly')} />
      {message !== null && <Notice text={message} />}
      <Button title="Activar el Plan Familiar" loading={purchase.isPending} onPress={buy} />
      <Button title="Restaurar compras" variant="secondary" loading={restore.isPending} onPress={restoreAll} />
      <AppText variant="tiny">
        El pago se hace con tu cuenta de Apple o Google y se renueva automáticamente. Puedes cancelarlo cuando quieras
        desde la tienda, como mínimo 24 h antes de la renovación. Si no pagas, Cerca sigue funcionando en el plan gratuito.
      </AppText>
      <Button title="Ahora no" variant="ghost" onPress={() => router.back()} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  feature: { flexDirection: 'row', gap: familySpacing.sm, alignItems: 'flex-start' },
  flex: { flex: 1 },
});
