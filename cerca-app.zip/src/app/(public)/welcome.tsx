import { router } from 'expo-router';
import { Heart, Sun, Users } from 'lucide-react-native';
import { StyleSheet, View } from 'react-native';

import { isDemoMode } from '@/shared/api/mode';
import { AppText, Button, Card, familyColors, familySpacing, Notice, Screen } from '@/shared/ui-family';

const VALUES = [
  { icon: Sun, title: 'Una foto cada mañana', text: 'Hijos y nietos comparten su día; los abuelos lo ven en grande.' },
  { icon: Heart, title: 'Un «buenos días» con un toque', text: 'El abuelo saluda a toda la familia sin escribir nada.' },
  { icon: Users, title: 'Tranquilidad para todos', text: 'Si un día no saluda, os avisamos para que le llaméis.' },
] as const;

export default function Welcome() {
  return (
    <Screen withBottomInset>
      <View style={styles.hero}>
        <AppText style={styles.logo}>☀️</AppText>
        <AppText variant="title" center>
          Cerca
        </AppText>
        <AppText center color={familyColors.textMuted}>
          La foto de cada mañana que mantiene unida a tu familia
        </AppText>
      </View>
      {VALUES.map((value) => (
        <Card key={value.title} tone="warm" style={styles.value}>
          <value.icon size={26} color={familyColors.terracotta} />
          <View style={styles.flex}>
            <AppText bold>{value.title}</AppText>
            <AppText variant="muted">{value.text}</AppText>
          </View>
        </Card>
      ))}
      {isDemoMode && <Notice tone="info" text="Modo prueba: datos de ejemplo guardados solo en este móvil." />}
      <Button title="Soy familiar: entrar" onPress={() => router.push('/login')} />
      <Button title="Soy el mayor: tengo un código" variant="secondary" onPress={() => router.push('/pair-elder')} />
      <AppText variant="tiny" center>
        Cerca es una red de comunicación familiar. No es un servicio médico ni sustituye al 112.
      </AppText>
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: { alignItems: 'center', gap: familySpacing.sm, paddingTop: familySpacing.xl, paddingBottom: familySpacing.md },
  logo: { fontSize: 56, lineHeight: 64 },
  value: { flexDirection: 'row', alignItems: 'center', gap: familySpacing.md },
  flex: { flex: 1, gap: 2 },
});
