import { router } from 'expo-router';
import { Settings } from 'lucide-react-native';
import { useEffect, useRef } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { useElderContext } from '@/features/auth-pairing';
import { GoodMorningButton, GreetingConfirmation, useButtonPressedToday, useFamilyCheckins, useGreeting } from '@/features/checkin-engine';
import { useElders } from '@/features/elder-config';
import { PhotoFrame, usePhotoOfTheDay } from '@/features/moments';
import { ElderScreen, ElderText, elderColors } from '@/shared/ui-elder';
import { formatLongDate, localDateIn, localTimeIn, timeToMinutes } from '@/shared/utils/dates';
import { successFeedback } from '@/shared/utils/haptics';

// Pantalla única del mayor: la foto del día y un solo botón protagonista.
export default function ElderHome() {
  const session = useElderContext();
  const familyId = session?.familyId;
  const timeZone = session?.timezone ?? 'Europe/Madrid';
  const { photo, isLoading } = usePhotoOfTheDay(familyId, timeZone);
  const checkins = useFamilyCheckins(familyId);
  const elders = useElders(familyId);
  const pressedToday = useButtonPressedToday(timeZone);
  const greeting = useGreeting(familyId ?? '', { id: session?.elderId ?? '', timezone: timeZone });
  const autoSent = useRef(false);

  const today = localDateIn(timeZone);
  const todayRow = checkins.data?.find((c) => c.elderId === session?.elderId && c.localDate === today);
  const greeted = todayRow?.status === 'ok';
  const myConfig = elders.data?.find((e) => e.id === session?.elderId);

  // Ver la foto del día dentro de la ventana de la mañana ya cuenta como señal (CONTEXT.md 3.2.4).
  useEffect(() => {
    if (photo === null || greeted || autoSent.current || myConfig === undefined) {
      return;
    }
    if (timeToMinutes(localTimeIn(timeZone)) >= timeToMinutes(myConfig.windowStart)) {
      autoSent.current = true;
      greeting.mutate('photo_opened');
    }
  }, [photo, greeted, myConfig, timeZone, greeting]);

  if (session === null) {
    return null;
  }

  function sayGoodMorning() {
    greeting.mutate('morning_button', { onSuccess: () => successFeedback() });
  }

  return (
    <ElderScreen>
      <View style={styles.topRow}>
        <ElderText variant="large" color={elderColors.textSoft} style={styles.date}>
          {formatLongDate(new Date(), timeZone)}
        </ElderText>
        {/* Ajustes ocultos: solo se abren manteniendo pulsado 4 segundos (para la familia). */}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Ajustes del móvil, para tu familia"
          delayLongPress={4000}
          onLongPress={() => router.push('/elder-settings')}
          hitSlop={12}
          style={styles.settings}
        >
          <Settings size={20} color={elderColors.border} />
        </Pressable>
      </View>
      <ElderText variant="hero">¡Buenos días!</ElderText>

      {photo !== null ? (
        <PhotoFrame photo={photo} timeZone={timeZone} />
      ) : (
        <View style={styles.empty}>
          <ElderText variant="large" center>
            {isLoading ? 'Cargando la foto de hoy…' : 'Muy pronto tu familia te enviará la primera foto 💛'}
          </ElderText>
        </View>
      )}

      {pressedToday ? (
        <GreetingConfirmation at={todayRow?.confirmedAt ?? null} timeZone={timeZone} />
      ) : (
        <GoodMorningButton onPress={sayGoodMorning} loading={greeting.isPending && greeting.variables === 'morning_button'} />
      )}
    </ElderScreen>
  );
}

const styles = StyleSheet.create({
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  date: { flex: 1, textTransform: 'capitalize' },
  settings: { padding: 8 },
  empty: {
    minHeight: 220,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: elderColors.border,
    backgroundColor: elderColors.memorySoft,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
});
