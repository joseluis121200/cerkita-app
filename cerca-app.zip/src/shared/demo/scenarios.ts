import { localDateIn } from '../utils/dates';
import { DEMO_IDS } from './seed';
import { resetDemo, updateDemo } from './store';
import type { DemoPersona } from './types';

// Acciones de la píldora "Modo Prueba Rápida" (solo __DEV__ y modo prueba).
export async function setDemoPersona(persona: DemoPersona): Promise<void> {
  await updateDemo((state) => {
    state.persona = persona;
  });
}

export async function toggleNoPhotoToday(): Promise<boolean> {
  return updateDemo((state) => {
    state.hideTodayPhotos = !state.hideTodayPhotos;
    return state.hideTodayPhotos;
  });
}

/** Simula que son las 11:30 y la abuela Carmen no ha dado señales: estado de aviso a admins. */
export async function simulateMissedGreeting(): Promise<void> {
  await updateDemo((state) => {
    const elder = state.elders.find((e) => e.id === DEMO_IDS.carmen);
    if (elder === undefined) {
      return;
    }
    const today = localDateIn(elder.timezone);
    state.checkins = state.checkins.filter((c) => !(c.elderId === elder.id && c.localDate === today));
    state.checkins.push({
      id: `c-alert-${Date.now()}`,
      elderId: elder.id,
      localDate: today,
      status: 'alerted_admins',
      confirmedAt: null,
      source: null,
      resolvedByUserId: null,
      resolutionNote: null,
    });
    state.persona = { kind: 'family', userId: DEMO_IDS.ruben };
  });
}

export async function restartDemo(): Promise<void> {
  await resetDemo();
}

export { DEMO_IDS };

/** Simula que acabó la prueba de 14 días sin pagar: plan gratuito con restricciones. */
export async function simulateFreePlan(): Promise<void> {
  await updateDemo((state) => {
    state.family.planStatus = 'free_limited';
    state.family.paidUntil = null;
    state.family.trialEndsAt = new Date(Date.now() - 86_400_000).toISOString();
    state.persona = { kind: 'family', userId: DEMO_IDS.ruben };
  });
}
