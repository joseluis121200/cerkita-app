import { addDays, DEFAULT_TIME_ZONE, isoAtLocalTime, localDateIn } from '../utils/dates';
import type { DemoCheckin, DemoElder, DemoMoment, DemoState } from './types';

// Datos realistas de la "Familia García" para probar todos los flujos en Expo Go.
export const DEMO_IDS = {
  family: 'f0000000-0000-4000-8000-000000000001',
  ruben: 'u0000000-0000-4000-8000-000000000001',
  marta: 'u0000000-0000-4000-8000-000000000002',
  lucia: 'u0000000-0000-4000-8000-000000000003',
  carmen: 'e0000000-0000-4000-8000-000000000001',
  pepe: 'e0000000-0000-4000-8000-000000000002',
} as const;

const CAPTIONS = [
  '¡Buenos días, abuela! Primer café de la mañana ☕',
  'Mirad qué amanecer desde la Alhambra 🌅',
  'Lucas ya se ata solo los cordones 👟',
  'Paseo con Lola por el parque 🐶',
  'Hoy toca gazpacho, ¡con tu receta! 🍅',
  'Camino del trabajo, os mando un abrazo 💛',
  'Las flores del balcón ya han salido 🌸',
  'Domingo de paella en familia 🥘',
  'Mira qué dibujo te ha hecho Sara 🎨',
  'Tarde de playa en Almuñécar 🏖️',
  'El huerto del pueblo está precioso 🌿',
  '¡Ya estamos todos deseando verte! 🤗',
];

const AUTHORS = [DEMO_IDS.lucia, DEMO_IDS.ruben, DEMO_IDS.marta];

function photoUrl(index: number): string {
  return `https://picsum.photos/seed/cerca-familia-${index}/900/1200`;
}

function seedMoments(now: Date): DemoMoment[] {
  const today = localDateIn(DEFAULT_TIME_ZONE, now);
  const moments: DemoMoment[] = [];
  for (let daysAgo = 11; daysAgo >= 1; daysAgo--) {
    const index = 11 - daysAgo;
    moments.push({
      id: `m-seed-${index}`,
      authorId: AUTHORS[index % AUTHORS.length] ?? DEMO_IDS.lucia,
      imageUrl: photoUrl(index),
      caption: CAPTIONS[index] ?? null,
      createdAt: isoAtLocalTime(DEFAULT_TIME_ZONE, addDays(today, -daysAgo), '08:30'),
    });
  }
  // La foto de hoy de Lucía a las 08:45 (o hace un rato, si aún es más temprano).
  const todayPhoto = new Date(isoAtLocalTime(DEFAULT_TIME_ZONE, today, '08:45'));
  const safeTime = todayPhoto.getTime() < now.getTime() ? todayPhoto : new Date(now.getTime() - 10 * 60_000);
  moments.push({
    id: 'm-seed-today',
    authorId: DEMO_IDS.lucia,
    imageUrl: photoUrl(99),
    caption: CAPTIONS[11] ?? null,
    createdAt: safeTime.toISOString(),
  });
  return moments;
}

function seedElders(now: Date): DemoElder[] {
  const base = {
    windowStart: '07:30',
    reminder1At: '10:30',
    reminder2At: '11:05',
    adminAlertAt: '11:30',
    activeDaysMask: 127,
    pausedUntil: null,
    isEnabled: true,
    createdAt: now.toISOString(),
  };
  return [
    { ...base, id: DEMO_IDS.carmen, userId: 'u-elder-carmen', displayName: 'Abuela Carmen', timezone: 'Europe/Madrid', phoneForCall: '+34600111222' },
    { ...base, id: DEMO_IDS.pepe, userId: 'u-elder-pepe', displayName: 'Abuelo Pepe', timezone: 'Atlantic/Canary', phoneForCall: '+34600333444' },
  ];
}

function seedCheckins(now: Date): DemoCheckin[] {
  const checkins: DemoCheckin[] = [];
  for (let daysAgo = 9; daysAgo >= 1; daysAgo--) {
    const carmenDate = addDays(localDateIn('Europe/Madrid', now), -daysAgo);
    checkins.push({
      id: `c-carmen-${daysAgo}`,
      elderId: DEMO_IDS.carmen,
      localDate: carmenDate,
      status: 'ok',
      confirmedAt: isoAtLocalTime('Europe/Madrid', carmenDate, '09:05'),
      source: 'morning_button',
      resolvedByUserId: null,
      resolutionNote: null,
    });
    const pepeDate = addDays(localDateIn('Atlantic/Canary', now), -daysAgo);
    const resolvedDay = daysAgo === 4;
    checkins.push({
      id: `c-pepe-${daysAgo}`,
      elderId: DEMO_IDS.pepe,
      localDate: pepeDate,
      status: resolvedDay ? 'resolved_by_admin' : 'ok',
      confirmedAt: isoAtLocalTime('Atlantic/Canary', pepeDate, resolvedDay ? '11:42' : '08:50'),
      source: resolvedDay ? 'manual_admin' : 'photo_opened',
      resolvedByUserId: resolvedDay ? DEMO_IDS.marta : null,
      resolutionNote: resolvedDay ? 'Estaba en el médico de cabecera, todo bien' : null,
    });
  }
  // Hoy: el abuelo Pepe ya saludó; la abuela Carmen aún no (para probar su pantalla).
  const pepeToday = localDateIn('Atlantic/Canary', now);
  const greeting = new Date(isoAtLocalTime('Atlantic/Canary', pepeToday, '09:18'));
  checkins.push({
    id: 'c-pepe-today',
    elderId: DEMO_IDS.pepe,
    localDate: pepeToday,
    status: 'ok',
    confirmedAt: (greeting.getTime() < now.getTime() ? greeting : new Date(now.getTime() - 5 * 60_000)).toISOString(),
    source: 'morning_button',
    resolvedByUserId: null,
    resolutionNote: null,
  });
  return checkins;
}

export function buildSeed(now: Date = new Date()): DemoState {
  const joinedAt = new Date(now.getTime() - 20 * 86_400_000).toISOString();
  return {
    version: 1,
    persona: { kind: 'signed_out' },
    family: {
      id: DEMO_IDS.family,
      name: 'Familia García',
      planStatus: 'trialing',
      trialEndsAt: new Date(now.getTime() + 11 * 86_400_000).toISOString(),
      paidUntil: null,
      inviteToken: '7c0f4f8e-5d2a-4c1b-9a63-2f1e8b7d6c5a',
    },
    profiles: [
      { id: DEMO_IDS.ruben, displayName: 'Rubén', email: 'ruben@ejemplo.es' },
      { id: DEMO_IDS.marta, displayName: 'Marta', email: 'marta@ejemplo.es' },
      { id: DEMO_IDS.lucia, displayName: 'Lucía', email: 'lucia@ejemplo.es' },
    ],
    members: [
      { id: 'fm-ruben', userId: DEMO_IDS.ruben, role: 'admin', label: 'Hijo Rubén', receiveCriticalEmails: true, joinedAt },
      { id: 'fm-marta', userId: DEMO_IDS.marta, role: 'admin', label: 'Hija Marta', receiveCriticalEmails: true, joinedAt },
      { id: 'fm-lucia', userId: DEMO_IDS.lucia, role: 'member', label: 'Nieta Lucía', receiveCriticalEmails: false, joinedAt },
      { id: 'fm-carmen', userId: 'u-elder-carmen', role: 'elder', label: 'Abuela Carmen', receiveCriticalEmails: false, joinedAt },
      { id: 'fm-pepe', userId: 'u-elder-pepe', role: 'elder', label: 'Abuelo Pepe', receiveCriticalEmails: false, joinedAt },
    ],
    elders: seedElders(now),
    moments: seedMoments(now),
    checkins: seedCheckins(now),
    pairingCodes: [],
    hideTodayPhotos: false,
  };
}
