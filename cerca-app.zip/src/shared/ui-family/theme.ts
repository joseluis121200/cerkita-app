// Tokens de diseño del modo familia: cálido, luminoso y mediterráneo (nada de estética de hospital).
export const familyColors = {
  background: '#FFFDF9',
  surface: '#FFFFFF',
  surfaceWarm: '#FFF7EC',
  border: '#F1E4D3',
  text: '#2B2118',
  textMuted: '#6B5B4D',
  primary: '#F59E0B',
  primaryPressed: '#D97706',
  onPrimary: '#2B2118',
  terracotta: '#C8553D',
  terracottaSoft: '#FBE4DD',
  calm: '#16A34A',
  calmSoft: '#DCFCE7',
  calmText: '#166534',
  warningSoft: '#FEF3C7',
  warningText: '#92400E',
  danger: '#B91C1C',
  dangerSoft: '#FEE2E2',
  white: '#FFFFFF',
} as const;

export const familySpacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 } as const;

export const familyRadius = { sm: 10, md: 16, lg: 24, pill: 999 } as const;

export const familyType = { title: 26, heading: 20, body: 16, small: 14, tiny: 12 } as const;
