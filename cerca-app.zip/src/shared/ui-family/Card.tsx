import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';

import { familyColors, familyRadius, familySpacing } from './theme';

type Tone = 'default' | 'warm' | 'calm' | 'alert' | 'warning';

const tones: Record<Tone, { bg: string; border: string }> = {
  default: { bg: familyColors.surface, border: familyColors.border },
  warm: { bg: familyColors.surfaceWarm, border: familyColors.border },
  calm: { bg: familyColors.calmSoft, border: '#BBF7D0' },
  alert: { bg: familyColors.terracottaSoft, border: familyColors.terracotta },
  warning: { bg: familyColors.warningSoft, border: '#FDE68A' },
};

type Props = { children: React.ReactNode; tone?: Tone; style?: StyleProp<ViewStyle> };

export function Card({ children, tone = 'default', style }: Props) {
  const colors = tones[tone];
  return <View style={[styles.card, { backgroundColor: colors.bg, borderColor: colors.border }, style]}>{children}</View>;
}

const styles = StyleSheet.create({
  card: {
    borderRadius: familyRadius.lg,
    borderWidth: 1,
    padding: familySpacing.lg,
    gap: familySpacing.sm,
  },
});
