// Tokens del Modo Mayor. Contraste AAA (≥ 7:1) y tamaños mínimos de AGENTS.md (sección 6).
export const elderColors = {
  background: '#FFFDF9',
  frame: '#FFFFFF',
  border: '#E7D7C1',
  text: '#1C1917',
  textSoft: '#44403C',
  primary: '#F59E0B',
  primaryPressed: '#D97706',
  onPrimary: '#1C1917',
  calm: '#14532D',
  calmSoft: '#DCFCE7',
  memory: '#7C2D12',
  memorySoft: '#FFEDD5',
} as const;

export const elderType = { body: 22, large: 26, title: 30, hero: 34 } as const;

// 68 dp: por encima de los 64 dp mínimos para dar margen a dedos con temblor.
export const elderSizes = { touchMin: 68, gap: 16, radius: 28, padding: 20 } as const;
