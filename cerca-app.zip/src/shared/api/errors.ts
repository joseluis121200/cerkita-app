// Traduce errores técnicos (Postgres, Supabase, red) a mensajes cálidos y claros en español.
const KNOWN_MESSAGES: { match: string; message: string }[] = [
  { match: 'Invalid or expired code', message: 'Ese código no es válido o ha caducado. Pide uno nuevo a tu familia.' },
  { match: 'Invalid invite link', message: 'Ese enlace de invitación no es válido. Pide otro a tu familia.' },
  { match: 'already has 10 members', message: 'Esta familia ya tiene 10 familiares, el máximo del plan.' },
  { match: 'at most 4 elders', message: 'Una familia puede tener como máximo 4 mayores.' },
  { match: 'at least one admin', message: 'La familia necesita al menos un administrador.' },
  { match: 'Not allowed', message: 'No tienes permiso para hacer esto.' },
  { match: 'Token has expired or is invalid', message: 'El código ha caducado o no es correcto. Pide uno nuevo.' },
  { match: 'Network request failed', message: 'No hay conexión a internet. Inténtalo de nuevo en un momento.' },
  { match: 'rate limit', message: 'Has hecho demasiados intentos. Espera unos minutos.' },
];

export function toUserMessage(error: unknown): string {
  const raw = error instanceof Error ? error.message : typeof error === 'string' ? error : '';
  for (const known of KNOWN_MESSAGES) {
    if (raw.toLowerCase().includes(known.match.toLowerCase())) {
      return known.message;
    }
  }
  if (raw.length > 0 && raw.length < 140 && /[áéíóúñ¿¡]/i.test(raw)) {
    return raw; // ya es un mensaje nuestro en español
  }
  return 'Algo no ha ido bien. Inténtalo de nuevo.';
}

/** Lanza el error de Supabase como Error normal para que TanStack Query lo gestione. */
export function throwIfError(error: { message: string } | null): void {
  if (error !== null) {
    throw new Error(error.message);
  }
}
